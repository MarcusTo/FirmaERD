﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class FirmaERD2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "Sick_LeaveId",
                table: "Healt_Inspection",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "AreaId",
                table: "Employee_Area",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Healt_Inspection_Sick_LeaveId",
                table: "Healt_Inspection",
                column: "Sick_LeaveId");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_Area_AreaId",
                table: "Employee_Area",
                column: "AreaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Employee_Area_Area_AreaId",
                table: "Employee_Area",
                column: "AreaId",
                principalTable: "Area",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Healt_Inspection_Sick_leave_Sick_LeaveId",
                table: "Healt_Inspection",
                column: "Sick_LeaveId",
                principalTable: "Sick_leave",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Employee_Area_Area_AreaId",
                table: "Employee_Area");

            migrationBuilder.DropForeignKey(
                name: "FK_Healt_Inspection_Sick_leave_Sick_LeaveId",
                table: "Healt_Inspection");

            migrationBuilder.DropIndex(
                name: "IX_Healt_Inspection_Sick_LeaveId",
                table: "Healt_Inspection");

            migrationBuilder.DropIndex(
                name: "IX_Employee_Area_AreaId",
                table: "Employee_Area");

            migrationBuilder.DropColumn(
                name: "Sick_LeaveId",
                table: "Healt_Inspection");

            migrationBuilder.DropColumn(
                name: "AreaId",
                table: "Employee_Area");
        }
    }
}
