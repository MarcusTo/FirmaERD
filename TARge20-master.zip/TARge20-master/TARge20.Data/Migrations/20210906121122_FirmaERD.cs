﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class FirmaERD : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Area",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    DateOfCreation = table.Column<string>(nullable: true),
                    ClosingDate = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Area", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Branch",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    RegisterNr = table.Column<string>(nullable: true),
                    Code = table.Column<Guid>(nullable: false),
                    Titel = table.Column<string>(nullable: true),
                    ArriveFrequency = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Branch", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employee_Access",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Employee_Id = table.Column<int>(nullable: false),
                    Accesses = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee_Access", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employee_Area",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Worker_ID = table.Column<int>(nullable: false),
                    Area_ID = table.Column<int>(nullable: false),
                    StartDate = table.Column<int>(nullable: false),
                    EndDate = table.Column<int>(nullable: false),
                    Comment = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee_Area", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employee_Children",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Employee_Id = table.Column<int>(nullable: false),
                    Quantity = table.Column<int>(nullable: false),
                    IDCode = table.Column<int>(nullable: false),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee_Children", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FirmaDB",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    RegisterNr = table.Column<int>(nullable: false),
                    Code = table.Column<int>(nullable: false),
                    ArriveFrequency = table.Column<int>(nullable: false),
                    Comment = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FirmaDB", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Healt_Inspection",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Employee_Id = table.Column<int>(nullable: false),
                    Health_Problems = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Healt_Inspection", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Hints",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Hint = table.Column<string>(nullable: true),
                    Hint_Date = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Hints", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Intranet_access",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Employee_Id = table.Column<int>(nullable: false),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Intranet_access", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Loan_from_Firms",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Employee_Id = table.Column<int>(nullable: false),
                    Loaned_Item = table.Column<string>(nullable: true),
                    Quantity = table.Column<int>(nullable: false),
                    Start = table.Column<int>(nullable: false),
                    End = table.Column<int>(nullable: false),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Loan_from_Firms", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Profession",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Employee_ID = table.Column<int>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeProfession = table.Column<string>(nullable: true),
                    Salary = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Profession", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Request",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Worker_Id = table.Column<int>(nullable: false),
                    Request_ = table.Column<string>(nullable: true),
                    RequestDate = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Request", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Sick_leave",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Employee_Id = table.Column<int>(nullable: false),
                    EmployeeHealth_Id = table.Column<string>(nullable: true),
                    Start = table.Column<int>(nullable: false),
                    End = table.Column<int>(nullable: false),
                    Disease = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sick_leave", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Vacation",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Employee_Id = table.Column<int>(nullable: false),
                    StartDate = table.Column<int>(nullable: false),
                    EndDate = table.Column<int>(nullable: false),
                    VacationType_Id = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    Symptoms = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vacation", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Vacation_Status",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vacation_Status", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Vacation_Type",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    VacationType = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vacation_Type", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Area");

            migrationBuilder.DropTable(
                name: "Branch");

            migrationBuilder.DropTable(
                name: "Employee");

            migrationBuilder.DropTable(
                name: "Employee_Access");

            migrationBuilder.DropTable(
                name: "Employee_Area");

            migrationBuilder.DropTable(
                name: "Employee_Children");

            migrationBuilder.DropTable(
                name: "FirmaDB");

            migrationBuilder.DropTable(
                name: "Healt_Inspection");

            migrationBuilder.DropTable(
                name: "Hints");

            migrationBuilder.DropTable(
                name: "Intranet_access");

            migrationBuilder.DropTable(
                name: "Loan_from_Firms");

            migrationBuilder.DropTable(
                name: "Profession");

            migrationBuilder.DropTable(
                name: "Request");

            migrationBuilder.DropTable(
                name: "Sick_leave");

            migrationBuilder.DropTable(
                name: "Vacation");

            migrationBuilder.DropTable(
                name: "Vacation_Status");

            migrationBuilder.DropTable(
                name: "Vacation_Type");
        }
    }
}
