﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TARge20.Core.Domain;

namespace TARge20.Data
{
    public class TARge20DbContext : DbContext
    {

        public TARge20DbContext(DbContextOptions<TARge20DbContext> options)
            : base(options) { }

        // näide, kuidas teha, kui lisate domaini alla ühe objekti
        // migratsioonid peavad tulema siia libary-sse e TARge20.Data alla.
        public DbSet<Employee> Employee { get; set; }
        public DbSet<Area> Area { get; set; }
        public DbSet<Branch> Branch { get; set; }
        public DbSet<Employee_Access> Employee_Access { get; set; }
        public DbSet<Employee_Area> Employee_Area  { get; set; }
        public DbSet<Employee_Children> Employee_Children { get; set; }
        public DbSet<FirmaDB> FirmaDB { get; set; }
        public DbSet<Health_Inspection> Healt_Inspection { get; set; }
        public DbSet<Hints> Hints { get; set; }
        public DbSet<Intranet_access> Intranet_access { get; set; }
        public DbSet<Loans_from_Firms> Loan_from_Firms { get; set; }
        public DbSet<Profession> Profession { get; set; }
        public DbSet<Request> Request { get; set; }
        public DbSet<Sick_Leave> Sick_leave { get; set; }
        public DbSet<Vacation_Status> Vacation_Status { get; set; }
        public DbSet<Vacation_Type> Vacation_Type { get; set; }
        public DbSet<Vacation> Vacation { get; set; }


    }
}