﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Employee_Children
    {
        [Key]
        public Guid Id { get; set; } 
        public int Employee_Id { get; set; }
        public int Quantity { get; set; }
        public int IDCode { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Comment { get; set; }


    }
}
