﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Employee_Area
    {
        [Key]
        public Guid Id { get; set; }
        public int Worker_ID { get; set; }
        public int Area_ID { get; set; }
        public int StartDate { get; set; }
        public int EndDate { get; set; }
        public int Comment { get; set; }


    }
}
