﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Request
    {
        [Key]
        public Guid Id { get; set; }
        public int Worker_Id { get; set; }
        public string Request_ { get; set; }
        public int RequestDate { get; set; }
    }
}
