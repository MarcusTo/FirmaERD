﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Employee_
    {
       [Key]
       public Guid Id { get; set; }
       public string Name { get; set; }
       public string LastName { get; set; }
       public int ID_Code { get; set; }
       public string MailAddress { get; set; }
       public int Phone_Number { get; set; }
       public int WorkFrom { get; set; }
       public int WorkUntil { get; set; }
       public int Age { get; set; }
       public string Gender { get; set; }
       public string Comment { get; set; }

        IEnumerable<Health_Inspection> Childrens { get; set; } = new List<Health_Inspection>();
        IEnumerable<Hints> Hints { get; set; } = new List<Hints>();
        IEnumerable<Request> Requests { get; set; } = new List<Request>();
        IEnumerable<Profession> Professions { get; set; } = new List<Profession>();
        IEnumerable<Loans_from_Firms> Loans_From_Firms { get; set; } = new List<Loans_from_Firms>();
        IEnumerable<Employee_Area> Employee_Areas { get; set; } = new List<Employee_Area>();
        IEnumerable<Vacation> Vacation { get; set; } = new List<Vacation>();
        IEnumerable<Sick_Leave> Sick_Leave { get; set; } = new List<Sick_Leave>();
        IEnumerable<Employee_Access> Employee_Accesses { get; set; } = new List<Employee_Access>();
        IEnumerable<Employee_Children> Employee_Childrens { get; set; } = new List<Employee_Children>();
        IEnumerable<Intranet_access> Intranet_Accesses { get; set; } = new List<Intranet_access>();
       

    }
}
