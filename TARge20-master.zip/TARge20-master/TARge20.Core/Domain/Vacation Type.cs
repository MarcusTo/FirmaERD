﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Vacation_Type
    {
        [Key]
        public Guid Id { get; set; }
        public string VacationType { get; set; }

    }
}
