﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TARge20
{
    public class FirmaDB
    {
        [Key]
        public Guid Id { get; set; }
        public int RegisterNr { get; set; }
        public int Code { get; set; }
        public int ArriveFrequency { get; set; }
        public int Comment { get; set; }


    }
}
