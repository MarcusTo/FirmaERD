﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Hints
    {
        [Key]
        public Guid Id { get; set; }
        public string Hint { get; set; }
        public string Hint_Date { get; set;}
    }
}
