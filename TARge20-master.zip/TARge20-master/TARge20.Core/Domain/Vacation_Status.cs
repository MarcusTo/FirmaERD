﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Vacation_Status
    {
        [Key]
        public Guid Id { get; set; }
        public string Status { get; set; }
    }
}
