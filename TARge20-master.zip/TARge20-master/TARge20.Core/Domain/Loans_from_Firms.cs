﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Loans_from_Firms
    {
        [Key]
        public Guid Id { get; set; }
        public int Employee_Id { get; set; }
        public string Loaned_Item { get; set; }
        public int Quantity { get; set; }
        public int Start { get; set; }
        public int End { get; set; }
        public string Comment { get; set; }


    }
}
