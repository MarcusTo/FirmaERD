﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Sick_Leave
    {
        [Key]
        public Guid Id { get; set; }
        public int Employee_Id { get; set; }
        public string EmployeeHealth_Id { get; set; }
        public int Start { get; set; }
        public int End { get; set; }
        public string Disease { get; set; }
        public string Comment { get; set; }
        public IEnumerable<Health_Inspection> Health_Inspections { get; set; } = new List<Health_Inspection>();


    }
}
