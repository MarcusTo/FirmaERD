﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Area
    {
        [Key]
        public Guid Id { get; set; }
        public IEnumerable<Employee_Area> EmployeeAreas { get; set; } = new List<Employee_Area>();
        public string Name { get; set;}
        public string DateOfCreation { get; set; }
        public string ClosingDate { get; set; }
        public string Comment { get; set; }

    }
}
