﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Profession
    {
        [Key]
        public Guid Id { get; set; }
        public int Employee_ID { get; set; }
        public string Comment { get; set; }
        public string EmployeeProfession { get; set; }
        public int Salary { get; set; }

    }
}
